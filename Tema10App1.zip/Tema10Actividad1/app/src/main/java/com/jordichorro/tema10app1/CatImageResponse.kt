package com.jordichorro.tema10app1

import com.google.gson.annotations.SerializedName

data class CatImageResponse(val url: String)